import java.time.LocalDate;
import java.util.*;

// =======================================================================
//  MedQueue - main entry point + all page / action handlers
//
//  Architecture:
//    Patient.java        - patient data record
//    MinHeap.java        - priority queue (binary min-heap)
//    CircularQueue.java  - appointment buffer (8-slot circular queue)
//    InputHelper.java    - all validated input primitives
//    UI.java             - ANSI constants, header/line printers, log
//    AppState.java       - mutable session state (one instance)
//    MedQueue.java       - main() + all menu/action methods  <- you are here
//
//  Screen-clear policy:
//    * cls() is called at the TOP of every menu redraw loop.
//    * When the user presses [0] Back, the method returns immediately
//      and the calling loop calls cls() before redrawing the parent menu -
//      so the child screen is always erased on exit.
// =======================================================================

public class MedQueue {

    // Single shared state object passed everywhere by reference
    private static final AppState S = new AppState();

    // ===================================================================
    //  ENTRY POINT
    // ===================================================================

    public static void main(String[] args) {
        // Force UTF-8 output so ANSI and line-drawing chars render on all terminals
        try {
            System.setOut(new java.io.PrintStream(System.out, true, "UTF-8"));
        } catch (Exception ignored) {}
        S.seedDemo();
        while (true) {
            UI.cls();
            UI.header("Hospital Patient Management System", S);
            System.out.println(UI.BOLD + "  MAIN MENU" + UI.RESET);
            System.out.println("  " + UI.GREEN   + "[1]" + UI.RESET + "  Admit Patient");
            System.out.println("  " + UI.RED     + "[2]" + UI.RESET + "  Priority Queue");
            System.out.println("  " + UI.BLUE    + "[3]" + UI.RESET + "  Appointments");
            System.out.println("  " + UI.MAGENTA + "[4]" + UI.RESET + "  Activity Log");
            System.out.println("  " + UI.YELLOW  + "[5]" + UI.RESET + "  Admin Panel");
            System.out.println("  " + UI.DIM     + "[0]" + UI.RESET + "  Exit");
            UI.line();
            try {
                switch (InputHelper.readMenu("  Choose: ", 0, 5)) {
                    case 1 -> pageAdmit();
                    case 2 -> pagePriorityQueue();
                    case 3 -> pageAppointments();
                    case 4 -> pageActivityLog();
                    case 5 -> pageAdmin();
                    case 0 -> {
                        if (showExitScreen()) return;
                        // showExitScreen returned false -> user chose to restart
                        // Reset state and fall through to redraw main menu
                        S.resetAll();
                        S.seedDemo();
                        UI.log("[SYSTEM] Session restarted.");
                    }
                }
            } catch (InputHelper.MainMenuException e) {
                // q from any sub-page -> back to main menu, just redraw
                UI.cls();
            } catch (InputHelper.BackException e) {
                // 0 on main menu -> redraw (0 is handled as a menu item via readMenu)
                UI.cls();
            }
        }
    }

    // ===================================================================
    //  EXIT SCREEN  - returns true = really quit, false = restart
    // ===================================================================

    /**
     * Shown when the user selects [0] Exit from the main menu.
     * Returns true  -> caller should return from main() (actual quit).
     * Returns false -> caller should reset state and restart the session.
     */
    static boolean showExitScreen() {
        while (true) {
            UI.cls();
            UI.dline();
            System.out.println(UI.BOLD + UI.CYAN + "  MedQueue  " + UI.RESET
                    + UI.BOLD + "|  Session Ended" + UI.RESET);
            UI.dline();
            System.out.println();
            System.out.println(UI.CYAN + "  Thank you for using MedQueue." + UI.RESET);
            System.out.println();
            UI.line();
            System.out.println("  " + UI.GREEN + "[1]" + UI.RESET + "  Start a new session  (reloads with fresh demo data)");
            System.out.println("  " + UI.RED   + "[0]" + UI.RESET + "  Quit");
            UI.line();
            try {
                int choice = InputHelper.readMenu("  Choose: ", 0, 1);
                if (choice == 1) {
                    UI.cls();
                    UI.msg(UI.GREEN + "[OK] Restarting session..." + UI.RESET);
                    try { Thread.sleep(800); } catch (InterruptedException ignored) {}
                    return false;   // signal: restart
                } else {
                    // choice == 0 -> confirm quit
                    UI.cls();
                    UI.dline();
                    System.out.println(UI.BOLD + UI.CYAN + "  MedQueue  " + UI.RESET
                            + UI.BOLD + "|  Goodbye" + UI.RESET);
                    UI.dline();
                    System.out.println();
                    System.out.println(UI.CYAN + "  Stay healthy!" + UI.RESET);
                    System.out.println();
                    return true;    // signal: actually quit
                }
            } catch (InputHelper.MainMenuException e) {
                // q on exit screen -> go back to main menu
                return false;
            } catch (InputHelper.BackException e) {
                // 0 is already handled as a menu item, but just in case
                return true;
            }
        }
    }

    // ===================================================================
    //  PAGE 1 - ADMIT PATIENT
    // ===================================================================

    static void pageAdmit() {
        while (true) {
            UI.cls();
            UI.header("Admit Patient  [Page 1 of 4]", S);
            System.out.println("  " + UI.GREEN + "[1]" + UI.RESET + "  Register New Patient");
            System.out.println("  " + UI.RED   + "[2]" + UI.RESET + "  Emergency Admission  (Severity 1 - jumps queue)");
            System.out.println("  " + UI.CYAN  + "[3]" + UI.RESET + "  View / Search Patient Records");
            System.out.println("  " + UI.DIM   + "[0]" + UI.RESET + "  Back");
            UI.line();
            try {
                switch (InputHelper.readMenu("  Choose: ", 0, 3)) {
                    case 1 -> flowAdmitPatient(false);
                    case 2 -> flowAdmitPatient(true);
                    case 3 -> flowViewRecords();
                    case 0 -> { UI.cls(); return; }
                }
            } catch (InputHelper.MainMenuException e) { UI.cls(); return; }
              catch (InputHelper.BackException  e) { UI.cls(); return; }
        }
    }

    // -- Multi-step admit flow ---------------------------------------------

    static void flowAdmitPatient(boolean forceEmergency) {
        try {
            flowAdmitPatientInner(forceEmergency);
        } catch (InputHelper.BackException e) {
            UI.cls();
            UI.msgPause(UI.YELLOW + "Admission cancelled -- returned to Admit menu." + UI.RESET);
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }

    static void flowAdmitPatientInner(boolean forceEmergency) {
        // ----------------------------------------------------------------
        //  Step-machine: step variable controls which field we are on.
        //  BackException  -> step--  (go back one field)
        //  MainMenuException -> rethrow (handled by flowAdmitPatient wrapper)
        //
        //  Steps:
        //    1  Name
        //    2  Age
        //    3  Gender
        //    4  Phone
        //    5  Doctor
        //    6  Preferred Time
        //    7  Condition
        //    8  Notes
        //    9  Severity  (skipped when forceEmergency)
        //   10  Commit + confirmation
        // ----------------------------------------------------------------

        final int TOTAL = forceEmergency ? 7 : 8;   // displayed step count
        String banner   = forceEmergency
                ? UI.BG_RED + " !! EMERGENCY ADMISSION !! " + UI.RESET
                : "Register New Patient";

        // Accumulated values -- null means "not yet collected"
        String name      = null;
        String age       = null;
        String gender    = null;
        String phone     = null;
        String doctor    = null;
        String apptTime  = null;
        String condition = null;
        String notes     = null;
        int    severity  = forceEmergency ? 1 : -1;

        int step = 1;   // start at first field

        while (step <= 10) {
            UI.cls();

            try {
                switch (step) {

                    // ── Step 1: Name ─────────────────────────────────────
                    case 1 -> {
                        UI.header(banner + (forceEmergency ? "" : "  (Step 1 / " + TOTAL + ")"), S);
                        if (forceEmergency)
                            System.out.println(UI.RED + UI.BOLD
                                    + "  Severity is forced to 1 - Critical." + UI.RESET);
                        System.out.println(UI.DIM + "  Fields marked * are required." + UI.RESET);
                        UI.line();
                        name = InputHelper.readLine("  Full Name *: ", true);
                        step++;
                    }

                    // ── Step 2: Age ──────────────────────────────────────
                    case 2 -> {
                        UI.header(banner + (forceEmergency ? "" : "  (Step 2 / " + TOTAL + ")"), S);
                        System.out.println(UI.CYAN + "  Patient: " + UI.BOLD + name + UI.RESET);
                        UI.line();
                        System.out.println(UI.DIM + "  Whole number 0-130, or press Enter to skip." + UI.RESET);
                        age = InputHelper.readAge("  Age: ");
                        step++;
                    }

                    // ── Step 3: Gender ───────────────────────────────────
                    case 3 -> {
                        UI.header(banner + (forceEmergency ? "" : "  (Step 3 / " + TOTAL + ")"), S);
                        System.out.println(UI.CYAN + "  Patient: " + UI.BOLD + name + UI.RESET
                                + (age.isEmpty() ? "" : "  |  Age: " + age));
                        UI.line();
                        System.out.println("  " + UI.WHITE + "[1]" + UI.RESET + "  Male");
                        System.out.println("  " + UI.WHITE + "[2]" + UI.RESET + "  Female");
                        System.out.println("  " + UI.WHITE + "[3]" + UI.RESET + "  Non-binary");
                        System.out.println("  " + UI.WHITE + "[4]" + UI.RESET + "  Other");
                        System.out.println("  " + UI.DIM   + "[0]" + UI.RESET + "  Prefer not to say");
                        UI.line();
                        // Gender uses readInt -- 0 means "prefer not to say" (valid),
                        // so we need to distinguish 0-the-value from 0-the-back-key.
                        // We use readMenu here so 0 is treated as a real choice,
                        // then step forward. User cannot back out of gender with 0
                        // but CAN press 0 to select "prefer not to say".
                        gender = switch (InputHelper.readMenu("  Gender: ", 0, 4)) {
                            case 1  -> "Male";
                            case 2  -> "Female";
                            case 3  -> "Non-binary";
                            case 4  -> "Other";
                            default -> "";
                        };
                        step++;
                    }

                    // ── Step 4: Phone ────────────────────────────────────
                    case 4 -> {
                        UI.header(banner + (forceEmergency ? "" : "  (Step 4 / " + TOTAL + ")"), S);
                        System.out.println(UI.CYAN + "  Patient: " + UI.BOLD + name + UI.RESET);
                        UI.line();
                        System.out.println(UI.DIM
                                + "  Digits, spaces, hyphens, parentheses (e.g. 416-555-0100)." + UI.RESET);
                        System.out.println(UI.DIM
                                + "  Minimum 7 digits required. Press Enter to skip." + UI.RESET);
                        phone = InputHelper.readPhone("  Phone: ");
                        step++;
                    }

                    // ── Step 5: Doctor ───────────────────────────────────
                    case 5 -> {
                        UI.header(banner + (forceEmergency ? "" : "  (Step 5 / " + TOTAL + ")"), S);
                        System.out.println(UI.CYAN + "  Patient: " + UI.BOLD + name + UI.RESET);
                        UI.line();
                        UI.printDoctorList(S);
                        UI.line();
                        int dIdx = InputHelper.readInt(
                                "  Select doctor [1-" + S.doctors.size() + "]: ", 1, S.doctors.size());
                        doctor = S.doctors.get(dIdx - 1);
                        step++;
                    }

                    // ── Step 6: Preferred Time ───────────────────────────
                    case 6 -> {
                        UI.header(banner + (forceEmergency ? "" : "  (Step 6 / " + TOTAL + ")"), S);
                        System.out.println(UI.CYAN + "  Patient: " + UI.BOLD + name + UI.RESET
                                + "  |  Doctor: " + UI.BOLD + doctor + UI.RESET);
                        UI.line();
                        System.out.println(UI.DIM + "  24-hour HH:MM  (e.g. 09:00, 14:30, 23:45)." + UI.RESET);
                        System.out.println(UI.DIM + "  Hour must be two digits - 09:00, not 9:00." + UI.RESET);
                        System.out.println(UI.DIM + "  Press Enter for default 09:00." + UI.RESET);
                        apptTime = InputHelper.readTime("  Preferred Time (HH:MM): ", "09:00", false);
                        step++;
                    }

                    // ── Step 7: Condition ────────────────────────────────
                    case 7 -> {
                        UI.header(banner + (forceEmergency ? "" : "  (Step 7 / " + TOTAL + ")"), S);
                        System.out.println(UI.CYAN + "  Patient: " + UI.BOLD + name + UI.RESET);
                        UI.line();
                        condition = InputHelper.readLine("  Condition / Symptoms *: ", true);
                        step++;
                    }

                    // ── Step 8: Notes ────────────────────────────────────
                    case 8 -> {
                        UI.header(banner + (forceEmergency ? "" : "  (Step 8 / " + TOTAL + ")"), S);
                        System.out.println(UI.CYAN + "  Patient: " + UI.BOLD + name + UI.RESET
                                + "  |  Condition: " + condition);
                        UI.line();
                        System.out.println(UI.DIM
                                + "  Allergies, past history, special instructions..."
                                + " Press Enter to skip." + UI.RESET);
                        notes = InputHelper.readLine("  Additional Notes: ", false);
                        step++;
                    }

                    // ── Step 9: Severity (skipped for emergency) ─────────
                    case 9 -> {
                        if (forceEmergency) {
                            // Skip straight to commit
                            step++;
                        } else {
                            UI.header("Register New Patient  (Step 8 / " + TOTAL + ")", S);
                            System.out.println(UI.CYAN + "  Patient: " + UI.BOLD + name + UI.RESET);
                            UI.line();
                            System.out.println(UI.BOLD
                                    + "  Severity Level   (1 = most critical -> 5 = routine)"
                                    + UI.RESET);
                            System.out.printf("  %s[1]%s  %-10s - Life-threatening. Immediate.%n",         UI.RED,    UI.RESET, "Critical");
                            System.out.printf("  %s[2]%s  %-10s - High risk. Seen within 15 min.%n",       UI.ORANGE, UI.RESET, "Urgent");
                            System.out.printf("  %s[3]%s  %-10s - Stable. Care within 1 hour.%n",          UI.YELLOW, UI.RESET, "Moderate");
                            System.out.printf("  %s[4]%s  %-10s - Low urgency. Up to 2 hours.%n",          UI.GREEN,  UI.RESET, "Minor");
                            System.out.printf("  %s[5]%s  %-10s - Non-urgent. Scheduled visit.%n",         UI.BLUE,   UI.RESET, "Routine");
                            UI.line();
                            severity = InputHelper.readInt("  Select severity [1-5]: ", 1, 5);
                            step++;
                        }
                    }

                    // ── Step 10: Commit + confirmation ───────────────────
                    default -> {
                        S.patientCount++;
                        boolean isEmergency = forceEmergency || severity == 1;
                        Patient p = new Patient(S.patientCount, name, age, gender, phone,
                                severity, doctor, apptTime, condition, notes, isEmergency);
                        if (isEmergency) {
                            S.emergencyCount++;
                            p.admitTime = 0L;
                        }
                        S.heap.insert(p);
                        S.patientRecords.add(p);
                        UI.log(String.format("[%s] %s - Sev %d (%s) . %s",
                                isEmergency ? "EMERGENCY" : "ADMIT",
                                name, severity, UI.SEV_LABELS[severity], doctor));

                        UI.cls();
                        UI.header(isEmergency
                                ? UI.BG_RED + " EMERGENCY ADMITTED " + UI.RESET
                                : "Patient Admitted", S);
                        System.out.println();
                        System.out.printf("  %s%-16s%s %s%s%s%n",     UI.CYAN, "Name:",       UI.RESET, UI.BOLD, name, UI.RESET);
                        System.out.printf("  %s%-16s%s %s%n",          UI.CYAN, "Age:",        UI.RESET, age.isEmpty()    ? "-" : age);
                        System.out.printf("  %s%-16s%s %s%n",          UI.CYAN, "Gender:",     UI.RESET, gender.isEmpty() ? "-" : gender);
                        System.out.printf("  %s%-16s%s %s%n",          UI.CYAN, "Phone:",      UI.RESET, phone.isEmpty()  ? "-" : phone);
                        System.out.printf("  %s%-16s%s %s%n",          UI.CYAN, "Doctor:",     UI.RESET, doctor);
                        System.out.printf("  %s%-16s%s %s%n",          UI.CYAN, "Pref. Time:", UI.RESET, apptTime);
                        System.out.printf("  %s%-16s%s %s%d - %s%s%n", UI.CYAN, "Severity:",   UI.RESET,
                                UI.SEV_COLOURS[severity], severity, UI.SEV_LABELS[severity], UI.RESET);
                        System.out.printf("  %s%-16s%s %s%n",          UI.CYAN, "Condition:",  UI.RESET, condition);
                        if (!notes.isEmpty())
                            System.out.printf("  %s%-16s%s %s%n",      UI.CYAN, "Notes:",      UI.RESET, notes);
                        System.out.printf("  %s%-16s%s %d%n",          UI.CYAN, "Patient ID:", UI.RESET, S.patientCount);
                        System.out.println();
                        UI.msgPause(isEmergency
                                ? UI.RED + UI.BOLD + "[EMERGENCY] " + name + " inserted at front of queue!" + UI.RESET
                                : UI.GREEN + "[OK] " + name + " admitted. Go to Appointments to book a date." + UI.RESET);
                        return;   // done
                    }
                }

            } catch (InputHelper.BackException e) {
                // z pressed -- go back one step, but never below step 1
                step = Math.max(1, step - 1);
                // Note: step 1 (name) at step-- stays at 1, so pressing z
                // on the Name field just redraws it -- the outer flowAdmitPatient
                // wrapper handles exiting the flow entirely via the Admit menu.

            } catch (InputHelper.MainMenuException e) {
                // Rethrow -- caught by flowAdmitPatient wrapper which clears and returns
                throw e;
            }
        }
    }

    static void flowViewRecords() {
        try {
            while (true) {
                UI.cls();
                UI.header("Patient Records  (" + S.patientRecords.size() + " total)", S);
                if (S.patientRecords.isEmpty()) {
                    System.out.println("  No patient records yet.");
                    UI.pressEnter();
                    return;
                }
                System.out.println("  " + UI.WHITE + "[1]" + UI.RESET + "  Show all");
                System.out.println("  " + UI.CYAN  + "[2]" + UI.RESET + "  Search by name / doctor / condition");
                System.out.println("  " + UI.DIM   + "[0]" + UI.RESET + "  Back");
                UI.line();
                int ch = InputHelper.readMenu("  Choose: ", 0, 2);
                if (ch == 0) { UI.cls(); return; }

                List<Patient> pool;
                if (ch == 2) {
                    UI.cls();
                    UI.header("Search Patient Records", S);
                    String q = InputHelper.readLine("  Search (name / doctor / condition): ", true).toLowerCase();
                    pool = new ArrayList<>();
                    for (Patient r : S.patientRecords)
                        if (r.name.toLowerCase().contains(q)
                                || r.doctor.toLowerCase().contains(q)
                                || r.condition.toLowerCase().contains(q))
                            pool.add(r);
                    if (pool.isEmpty()) { UI.msgPause(UI.YELLOW + "No records match." + UI.RESET); continue; }
                } else {
                    pool = new ArrayList<>(S.patientRecords);
                }

                UI.cls();
                UI.header("Patient Records  (" + pool.size() + " shown)", S);
                Collections.reverse(pool);
                for (Patient r : pool) {
                    String sc = UI.SEV_COLOURS[r.severity];
                    System.out.printf("  %s%s[Sev %d - %-8s]%s  %s%-22s%s  %s%n",
                            r.emergency ? UI.RED + "(!) " : "    ",
                            sc, r.severity, UI.SEV_LABELS[r.severity], UI.RESET,
                            UI.BOLD, r.name, UI.RESET, UI.statusLabel(r.status));
                    System.out.printf("      Age: %-5s  Gender: %-12s  Phone: %s%n",
                            r.age, r.gender.isEmpty() ? "-" : r.gender,
                            r.phone.isEmpty() ? "-" : r.phone);
                    System.out.printf("      Doctor: %-14s  Pref. Time: %s%n", r.doctor, r.apptTime);
                    if (!r.apptDate.isEmpty())
                        System.out.printf("      Appt Date: %s%n", r.apptDate);
                    System.out.printf("      Condition: %s%n", r.condition);
                    if (!r.notes.isEmpty()) System.out.printf("      Notes: %s%n", r.notes);
                    System.out.printf("      Admitted: %s%n", r.admitDate);
                    UI.line();
                }
                UI.pressEnter();
            }
    
        } catch (InputHelper.BackException e) {
            UI.cls();
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }

    // ===================================================================
    //  PAGE 2 - PRIORITY QUEUE
    // ===================================================================

    static void pagePriorityQueue() {
        while (true) {
            UI.cls();
            UI.header("Priority Queue  [Page 2 of 4]", S);
            List<Patient> sorted = S.heap.sorted();
            if (sorted.isEmpty()) {
                System.out.println("  " + UI.YELLOW + "Queue is empty." + UI.RESET);
            } else {
                System.out.printf("  %-5s  %-14s  %-22s  %-14s  %-7s  %s%n",
                        "Rank", "Severity", "Name", "Doctor", "Time", "Condition");
                UI.line();
                for (int i = 0; i < sorted.size(); i++) {
                    Patient p  = sorted.get(i);
                    String  sc = UI.SEV_COLOURS[p.severity];
                    String rank = (i == 0) ? UI.RED + UI.BOLD + ">> #1 " + UI.RESET : "  #" + (i + 1);
                    String cond = p.condition.length() > 24
                            ? p.condition.substring(0, 21) + "..." : p.condition;
                    System.out.printf("  %-5s  %s%-14s%s  %-22s  %-14s  %-7s  %s%n",
                            rank, sc, p.severity + " " + UI.SEV_ICONS[p.severity], UI.RESET,
                            p.name + (p.emergency ? " (!)" : ""),
                            p.doctor, p.apptTime, cond);
                }
            }
            UI.line();
            System.out.println("  " + UI.GREEN + "[1]" + UI.RESET + "  Treat Next  (Extract-Min)");
            System.out.println("  " + UI.GREEN + "[2]" + UI.RESET + "  Treat Specific Patient by ID");
            System.out.println("  " + UI.RED   + "[3]" + UI.RESET + "  Remove Patient by ID");
            System.out.println("  " + UI.CYAN  + "[4]" + UI.RESET + "  Show Raw Heap Array");
            System.out.println("  " + UI.DIM   + "[0]" + UI.RESET + "  Back");
            UI.line();
            try {
                switch (InputHelper.readMenu("  Choose: ", 0, 4)) {
                    case 1 -> actionTreatNext();
                    case 2 -> actionTreatSpecific();
                    case 3 -> actionRemovePatient();
                    case 4 -> actionShowHeapArray();
                    case 0 -> { UI.cls(); return; }
                }
            } catch (InputHelper.MainMenuException e) { UI.cls(); return; }
              catch (InputHelper.BackException  e) { UI.cls(); return; }
        }
    }

    static void actionTreatNext() {
        UI.cls();
        UI.header("Treat Next Patient", S);
        Patient p = S.heap.extractMin();
        if (p == null) { UI.msgPause(UI.YELLOW + "Queue is empty." + UI.RESET); return; }
        S.treatedCount++;
        S.setStatus(p.id, "treated");
        UI.log(String.format("[TREATED] %s (Sev %d) treated by %s. Discharged.", p.name, p.severity, p.doctor));
        UI.msgPause(UI.GREEN + "[OK] " + UI.BOLD + p.name + UI.RESET + UI.GREEN
                + " (Sev " + p.severity + ") treated & discharged by " + p.doctor + "." + UI.RESET);
    }

    static void actionTreatSpecific() {
        try {
            UI.cls();
            UI.header("Treat Specific Patient", S);
            if (S.heap.isEmpty()) { UI.msgPause(UI.YELLOW + "Queue is empty." + UI.RESET); return; }
            UI.printQueueTable(S);
            UI.line();
            int id = InputHelper.readInt("  Enter Patient ID to treat: ", 1, Integer.MAX_VALUE);
            Patient p = S.heap.findById(id);
            if (p == null) { UI.msgPause(UI.RED + "[X]  ID " + id + " not found in queue." + UI.RESET); return; }
            S.heap.remove(id);
            S.treatedCount++;
            S.setStatus(id, "treated");
            UI.log("[TREATED] " + p.name + " treated directly.");
            UI.msgPause(UI.GREEN + "[OK] " + UI.BOLD + p.name + UI.RESET + UI.GREEN + " treated." + UI.RESET);
    
        } catch (InputHelper.BackException e) {
            UI.cls();
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }

    static void actionRemovePatient() {
        try {
            UI.cls();
            UI.header("Remove Patient", S);
            if (S.heap.isEmpty()) { UI.msgPause(UI.YELLOW + "Queue is empty." + UI.RESET); return; }
            UI.printQueueTable(S);
            UI.line();
            int id = InputHelper.readInt("  Enter Patient ID to remove: ", 1, Integer.MAX_VALUE);
            Patient p = S.heap.findById(id);
            if (p == null) { UI.msgPause(UI.RED + "[X]  ID " + id + " not found in queue." + UI.RESET); return; }
            if (!InputHelper.readYesNo("  Remove " + UI.BOLD + p.name + UI.RESET + " from the system")) {
                UI.msgPause(UI.YELLOW + "Cancelled." + UI.RESET); return;
            }
            S.heap.remove(id);
            S.cq.removeByPatientId(id);
            S.setStatus(id, "removed");
            UI.log("[REMOVED] " + p.name + " removed from system.");
            UI.msgPause(UI.RED + "[DEL]  " + p.name + " removed." + UI.RESET);
    
        } catch (InputHelper.BackException e) {
            UI.cls();
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }

    static void actionShowHeapArray() {
        UI.cls();
        UI.header("Raw Heap Array", S);
        List<Patient> raw = S.heap.rawArray();
        if (raw.isEmpty()) {
            System.out.println("  Heap array is empty.");
        } else {
            System.out.println(UI.CYAN + "  Backing array - index 0 = root = highest priority" + UI.RESET);
            UI.line();
            for (int i = 0; i < raw.size(); i++) {
                Patient p = raw.get(i);
                System.out.printf("  [%2d]  %sSev:%d  %-8s%s  %-22s  ID:%-4d%n",
                        i, UI.SEV_COLOURS[p.severity], p.severity, UI.SEV_LABELS[p.severity], UI.RESET,
                        p.name, p.id);
            }
        }
        UI.pressEnter();
    }

    // ===================================================================
    //  PAGE 3 - APPOINTMENTS  (Circular Queue)
    //
    //  New features:
    //    * Book appointment for ANY patient in the queue (not just top)
    //    * Choose date (YYYY-MM-DD) and time (HH:MM) per booking
    //    * Search/filter slots by date
    //    * Complete (dequeue) the HEAD appointment
    // ===================================================================

    static void pageAppointments() {
        while (true) {
            UI.cls();
            UI.header("Appointments  [Page 3 of 4]", S);

            // Pointer info
            int tailIdx = S.cq.isEmpty() ? -1 : (S.cq.tail - 1 + CircularQueue.CAP) % CircularQueue.CAP;
            System.out.printf(
                "  Capacity: %d  |  Used: %s%d%s  |  HEAD: %s[%d]%s  |  TAIL: %s[%s]%s%n",
                CircularQueue.CAP,
                UI.YELLOW, S.cq.count, UI.RESET,
                UI.GREEN,  S.cq.head,  UI.RESET,
                UI.YELLOW, S.cq.isEmpty() ? "-" : String.valueOf(tailIdx), UI.RESET);
            UI.line();

            // Slot display
            System.out.println(UI.BOLD + "  Appointment Slots:" + UI.RESET);
            for (int i = 0; i < CircularQueue.CAP; i++) {
                CircularQueue.Appointment a = S.cq.data[i];
                boolean isHead = !S.cq.isEmpty() && i == S.cq.head;
                boolean isTail = !S.cq.isEmpty() && i == tailIdx;
                String  col    = (a == null) ? UI.DIM
                               : (isHead ? UI.GREEN : (isTail ? UI.YELLOW : UI.BLUE));
                String  ptr    = "";
                if      (isHead && isTail && a != null) ptr = UI.GREEN  + " [HEAD+TAIL]" + UI.RESET;
                else if (isHead && a != null)           ptr = UI.GREEN  + " [HEAD]"      + UI.RESET;
                else if (isTail && a != null)           ptr = UI.YELLOW + " [TAIL]"      + UI.RESET;

                if (a != null) {
                    System.out.printf("  %s[%d]%s  %-22s  %s  %s  %s%s%n",
                            col, i, UI.RESET,
                            a.patient.name,
                            a.date, a.time, a.doctor, ptr);
                } else {
                    System.out.printf("  %s[%d]  <empty>%s%n", col, i, UI.RESET);
                }
            }

            UI.line();
            System.out.println("  " + UI.GREEN  + "[1]" + UI.RESET + "  Book Appointment  (choose patient, date & time)");
            System.out.println("  " + UI.RED    + "[2]" + UI.RESET + "  Complete Next Appointment  (Dequeue HEAD)");
            System.out.println("  " + UI.YELLOW + "[3]" + UI.RESET + "  Cancel Appointment  (remove a booked slot)");
            System.out.println("  " + UI.CYAN   + "[4]" + UI.RESET + "  Search Appointments by Date");
            System.out.println("  " + UI.DIM    + "[0]" + UI.RESET + "  Back");
            UI.line();
            try {
                switch (InputHelper.readMenu("  Choose: ", 0, 4)) {
                    case 1 -> actionBookAppointment();
                    case 2 -> actionCompleteAppointment();
                    case 3 -> actionCancelAppointment();
                    case 4 -> actionSearchByDate();
                    case 0 -> { UI.cls(); return; }
                }
            } catch (InputHelper.MainMenuException e) { UI.cls(); return; }
              catch (InputHelper.BackException  e) { UI.cls(); return; }
        }
    }

    // -- Book an appointment -----------------------------------------------

    static void actionBookAppointment() {
        try {
            // Guard: queue full?
            if (S.cq.isFull()) {
                UI.cls();
                UI.header("Book Appointment", S);
                UI.msgPause(UI.RED + "[X]  Appointment queue is full (8/8). Complete an appointment first." + UI.RESET);
                return;
            }
            // Guard: nobody to schedule?
            if (S.heap.isEmpty()) {
                UI.cls();
                UI.header("Book Appointment", S);
                UI.msgPause(UI.YELLOW + "No patients in the priority queue to schedule." + UI.RESET);
                return;
            }

            // -- Step 1: Choose patient ------------------------------------
            UI.cls();
            UI.header("Book Appointment  (Step 1 / 3) - Select Patient", S);
            List<Patient> queue = S.heap.sorted();
            System.out.printf("  %-6s  %-14s  %-22s  %-14s  Status%n",
                    "ID", "Severity", "Name", "Doctor");
            UI.line();
            for (Patient p : queue) {
                String sc     = UI.SEV_COLOURS[p.severity];
                String status = p.apptDate.isEmpty() ? UI.YELLOW + "Not booked" + UI.RESET
                                                     : UI.BLUE   + "Booked " + p.apptDate + UI.RESET;
                System.out.printf("  %-6d  %s%-14s%s  %-22s  %-14s  %s%n",
                        p.id, sc, p.severity + " " + UI.SEV_LABELS[p.severity], UI.RESET,
                        p.name + (p.emergency ? " (!)" : ""), p.doctor, status);
            }
            UI.line();
            System.out.println(UI.DIM + "  Enter the Patient ID from the list above." + UI.RESET);
            int patientId = InputHelper.readInt("  Patient ID: ", 1, Integer.MAX_VALUE);
            Patient chosen = S.heap.findById(patientId);
            if (chosen == null) {
                UI.msgPause(UI.RED + "[X]  Patient ID " + patientId + " not found in the priority queue." + UI.RESET);
                return;
            }

            // -- Step 2: Choose date ---------------------------------------
            UI.cls();
            UI.header("Book Appointment  (Step 2 / 3) - Choose Date", S);
            System.out.println(UI.CYAN + "  Patient: " + UI.BOLD + chosen.name + UI.RESET
                    + "  |  Doctor: " + UI.BOLD + chosen.doctor + UI.RESET);
            UI.line();
            System.out.println(UI.DIM + "  Format: YYYY-MM-DD  (e.g. " + LocalDate.now() + ")." + UI.RESET);
            System.out.println(UI.DIM + "  Must be today or a future date." + UI.RESET);
            String date = InputHelper.readDate("  Appointment Date (YYYY-MM-DD): ",
                    LocalDate.now().toString(), true);

            // -- Step 3: Choose time ---------------------------------------
            UI.cls();
            UI.header("Book Appointment  (Step 3 / 3) - Choose Time", S);
            System.out.println(UI.CYAN + "  Patient: " + UI.BOLD + chosen.name + UI.RESET
                    + "  |  Date: " + UI.BOLD + date + UI.RESET
                    + "  |  Doctor: " + UI.BOLD + chosen.doctor + UI.RESET);
            UI.line();
            System.out.println(UI.DIM + "  24-hour HH:MM  (e.g. 09:00, 14:30)." + UI.RESET);
            System.out.printf( UI.DIM + "  Patient's preferred time: %s%s%n" + UI.RESET,
                    chosen.apptTime, UI.RESET);
            System.out.println(UI.DIM + "  Press Enter to use the patient's preferred time." + UI.RESET);
            String time = InputHelper.readTime(
                    "  Appointment Time (HH:MM): ", chosen.apptTime, false);

            // -- Confirm ---------------------------------------------------
            UI.cls();
            UI.header("Book Appointment - Confirm", S);
            System.out.println();
            System.out.printf("  %s%-16s%s %s%s%s%n", UI.CYAN, "Patient:",  UI.RESET, UI.BOLD, chosen.name,   UI.RESET);
            System.out.printf("  %s%-16s%s %s%d - %s%s%n", UI.CYAN, "Severity:", UI.RESET,
                    UI.SEV_COLOURS[chosen.severity], chosen.severity, UI.SEV_LABELS[chosen.severity], UI.RESET);
            System.out.printf("  %s%-16s%s %s%n", UI.CYAN, "Doctor:",    UI.RESET, chosen.doctor);
            System.out.printf("  %s%-16s%s %s%n", UI.CYAN, "Date:",      UI.RESET, date);
            System.out.printf("  %s%-16s%s %s%n", UI.CYAN, "Time:",      UI.RESET, time);
            System.out.println();
            if (!InputHelper.readYesNo("  Confirm this appointment")) {
                UI.msgPause(UI.YELLOW + "Cancelled." + UI.RESET); return;
            }

            // -- Commit ----------------------------------------------------
            Patient snap  = chosen.copy();
            snap.apptDate = date;
            snap.apptTime = time;
            snap.status   = "scheduled";
            CircularQueue.Appointment appt = new CircularQueue.Appointment(snap, date, time, chosen.doctor);

            if (!S.cq.enqueue(appt)) {
                UI.msgPause(UI.RED + "[X]  Queue became full just now. Try again." + UI.RESET); return;
            }

            // Update the live heap record too
            chosen.apptDate = date;
            chosen.apptTime = time;
            S.setStatus(chosen.id, "scheduled");

            int slot = (S.cq.tail - 1 + CircularQueue.CAP) % CircularQueue.CAP;
            UI.log(String.format("[SCHEDULED] %s booked with %s on %s at %s -> slot [%d]",
                    chosen.name, chosen.doctor, date, time, slot));
            UI.msgPause(UI.BLUE + "[APPT] Appointment booked for " + UI.BOLD + chosen.name + UI.RESET + UI.BLUE
                    + " on " + date + " at " + time + " -> slot [" + slot + "]." + UI.RESET);
    
        } catch (InputHelper.BackException e) {
            UI.cls();
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }

    // -- Complete a chosen appointment ------------------------------------

    static void actionCompleteAppointment() {
        try {
            UI.cls();
            UI.header("Complete Appointment", S);

            if (S.cq.isEmpty()) {
                UI.msgPause(UI.YELLOW + "No appointments are currently booked." + UI.RESET);
                return;
            }

            // Show all filled slots
            System.out.println(UI.BOLD + "  Booked Appointments:" + UI.RESET);
            UI.line();
            for (int i = 0; i < CircularQueue.CAP; i++) {
                CircularQueue.Appointment a = S.cq.data[i];
                if (a == null) continue;
                boolean isHead = i == S.cq.head;
                String tag = isHead ? UI.GREEN + " [HEAD - next in queue]" + UI.RESET : "";
                System.out.printf("  Slot %s[%d]%s  %-22s  %-12s  %-8s  %s%s%n",
                        UI.CYAN, i, UI.RESET,
                        a.patient.name, a.date, a.time, a.doctor, tag);
            }
            UI.line();
            System.out.println(UI.DIM + "  Enter the slot number of the appointment to mark complete." + UI.RESET);
            int slot = InputHelper.readInt("  Slot number [0-7]: ", 0, CircularQueue.CAP - 1);

            CircularQueue.Appointment target = S.cq.data[slot];
            if (target == null) {
                UI.msgPause(UI.RED + "[X]  Slot [" + slot + "] is empty." + UI.RESET);
                return;
            }

            // Confirm
            UI.cls();
            UI.header("Complete Appointment - Confirm", S);
            System.out.println();
            System.out.printf("  %s%-16s%s %s%s%s%n",   UI.CYAN, "Patient:", UI.RESET, UI.BOLD, target.patient.name, UI.RESET);
            System.out.printf("  %s%-16s%s %s%n",        UI.CYAN, "Doctor:",  UI.RESET, target.doctor);
            System.out.printf("  %s%-16s%s %s%n",        UI.CYAN, "Date:",    UI.RESET, target.date);
            System.out.printf("  %s%-16s%s %s%n",        UI.CYAN, "Time:",    UI.RESET, target.time);
            System.out.printf("  %s%-16s%s Slot [%d]%n", UI.CYAN, "Slot:",    UI.RESET, slot);
            System.out.println();
            if (!InputHelper.readYesNo("  Mark this appointment as complete")) {
                UI.msgPause(UI.YELLOW + "Cancelled." + UI.RESET);
                return;
            }

            // Remove from slot directly (does not have to be HEAD)
            S.cq.data[slot] = null;
            S.cq.count = Math.max(0, S.cq.count - 1);

            // If we cleared the HEAD, advance it to the next filled slot
            if (slot == S.cq.head) {
                int searched = 0;
                while (S.cq.count > 0 && S.cq.data[S.cq.head] == null && searched < CircularQueue.CAP) {
                    S.cq.head = (S.cq.head + 1) % CircularQueue.CAP;
                    searched++;
                }
            }

            // Update patient status
            S.heap.remove(target.patient.id);
            S.treatedCount++;
            S.setStatus(target.patient.id, "treated");
            UI.log(String.format("[COMPLETED] %s seen by %s on %s at %s.",
                    target.patient.name, target.doctor, target.date, target.time));
            UI.msgPause(UI.GREEN + "[DONE] Appointment completed - " + UI.BOLD + target.patient.name + UI.RESET
                    + UI.GREEN + " seen by " + target.doctor + " on " + target.date
                    + " at " + target.time + "." + UI.RESET);

        } catch (InputHelper.BackException e) {
            UI.cls();
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }

    // -- Cancel an appointment (remove it from a specific slot) ----------------

    static void actionCancelAppointment() {
        try {
            UI.cls();
            UI.header("Cancel Appointment", S);

            if (S.cq.isEmpty()) {
                UI.msgPause(UI.YELLOW + "No appointments are currently booked." + UI.RESET);
                return;
            }

            // Show all filled slots so the user can pick one
            int tailIdx = (S.cq.tail - 1 + CircularQueue.CAP) % CircularQueue.CAP;
            System.out.println(UI.BOLD + "  Booked Slots:" + UI.RESET);
            UI.line();
            boolean anyFilled = false;
            for (int i = 0; i < CircularQueue.CAP; i++) {
                CircularQueue.Appointment a = S.cq.data[i];
                if (a == null) continue;
                anyFilled = true;
                boolean isHead = i == S.cq.head;
                String tag = isHead ? UI.GREEN + " [HEAD - next up]" + UI.RESET : "";
                System.out.printf("  Slot %s[%d]%s  %-22s  %s  %s  %s%s%n",
                        UI.CYAN, i, UI.RESET,
                        a.patient.name,
                        a.date, a.time, a.doctor, tag);
            }
            if (!anyFilled) {
                UI.msgPause(UI.YELLOW + "No booked slots found." + UI.RESET);
                return;
            }

            UI.line();
            System.out.println(UI.DIM + "  Enter the slot number [0-7] of the appointment to cancel." + UI.RESET);
            int slot = InputHelper.readInt("  Slot number: ", 0, CircularQueue.CAP - 1);

            CircularQueue.Appointment target = S.cq.data[slot];
            if (target == null) {
                UI.msgPause(UI.RED + "[X]  Slot [" + slot + "] is already empty." + UI.RESET);
                return;
            }

            // Confirm
            UI.cls();
            UI.header("Cancel Appointment - Confirm", S);
            System.out.println();
            System.out.printf("  %s%-16s%s %s%s%s%n",   UI.CYAN, "Patient:", UI.RESET, UI.BOLD, target.patient.name, UI.RESET);
            System.out.printf("  %s%-16s%s %s%n",        UI.CYAN, "Doctor:",  UI.RESET, target.doctor);
            System.out.printf("  %s%-16s%s %s%n",        UI.CYAN, "Date:",    UI.RESET, target.date);
            System.out.printf("  %s%-16s%s %s%n",        UI.CYAN, "Time:",    UI.RESET, target.time);
            System.out.printf("  %s%-16s%s Slot [%d]%n", UI.CYAN, "Slot:",    UI.RESET, slot);
            System.out.println();
            System.out.println(UI.YELLOW
                    + "  Note: The patient remains in the priority queue and can be re-booked."
                    + UI.RESET);
            System.out.println();

            if (!InputHelper.readYesNo("  Cancel this appointment")) {
                UI.msgPause(UI.YELLOW + "Cancelled -- no changes made." + UI.RESET);
                return;
            }

            // Remove from circular queue slot directly (not a standard dequeue)
            String patientName = target.patient.name;
            int    patientId   = target.patient.id;
            S.cq.data[slot]    = null;
            S.cq.count         = Math.max(0, S.cq.count - 1);

            // If we removed the HEAD slot, advance HEAD to the next filled slot
            if (slot == S.cq.head && !S.cq.isEmpty()) {
                while (S.cq.data[S.cq.head] == null && S.cq.count > 0) {
                    S.cq.head = (S.cq.head + 1) % CircularQueue.CAP;
                }
            }

            // Revert the patient's status back to "waiting" and clear apptDate
            S.setStatus(patientId, "waiting");
            Patient live = S.heap.findById(patientId);
            if (live != null) { live.apptDate = ""; live.apptTime = live.apptTime; }
            Patient rec = S.findRecord(patientId);
            if (rec != null) rec.apptDate = "";

            UI.log("[CANCELLED] Appointment for " + patientName
                    + " on " + target.date + " at " + target.time + " cancelled.");
            UI.msgPause(UI.YELLOW + "[X] Appointment for " + UI.BOLD + patientName + UI.RESET
                    + UI.YELLOW + " on " + target.date + " at " + target.time
                    + " has been cancelled. Patient returned to waiting." + UI.RESET);

        } catch (InputHelper.BackException e) {
            UI.cls();
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }

    // -- Search appointments by date ---------------------------------------

    static void actionSearchByDate() {
        try {
            UI.cls();
            UI.header("Search Appointments by Date", S);
            if (S.cq.isEmpty()) { UI.msgPause(UI.YELLOW + "No appointments booked." + UI.RESET); return; }

            System.out.println(UI.DIM + "  Format: YYYY-MM-DD  (e.g. " + LocalDate.now() + ")." + UI.RESET);
            System.out.println(UI.DIM + "  Enter a date to see all appointments on that day." + UI.RESET);
            UI.line();
            System.out.print("  Date (YYYY-MM-DD): ");
            // We allow past dates here (just viewing), so we do a simple parse check
            String query = InputHelper.rawLine();
            try {
                java.time.LocalDate.parse(query);
            } catch (Exception e) {
                UI.msgPause(UI.RED + "[X]  \"" + query + "\" is not a valid date. Format: YYYY-MM-DD." + UI.RESET);
                return;
            }

            UI.cls();
            UI.header("Appointments on " + query, S);
            boolean found = false;
            for (int i = 0; i < CircularQueue.CAP; i++) {
                CircularQueue.Appointment a = S.cq.data[i];
                if (a != null && query.equals(a.date)) {
                    found = true;
                    boolean isHead = i == S.cq.head;
                    String  label  = isHead ? UI.GREEN + " [HEAD - next]" + UI.RESET : "";
                    System.out.printf("  Slot [%d]%s%n", i, label);
                    System.out.printf("    Patient : %s%s%s%n", UI.BOLD, a.patient.name, UI.RESET);
                    System.out.printf("    Severity: %s%d - %s%s%n",
                            UI.SEV_COLOURS[a.patient.severity],
                            a.patient.severity, UI.SEV_LABELS[a.patient.severity], UI.RESET);
                    System.out.printf("    Doctor  : %s%n", a.doctor);
                    System.out.printf("    Time    : %s%n", a.time);
                    System.out.printf("    Booked  : %s%n", a.bookedAt);
                    UI.line();
                }
            }
            if (!found)
                System.out.println("  " + UI.YELLOW + "No appointments found for " + query + "." + UI.RESET);
            UI.pressEnter();
    
        } catch (InputHelper.BackException e) {
            UI.cls();
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }

    // ===================================================================
    //  PAGE 4 - ACTIVITY LOG
    // ===================================================================

    static void pageActivityLog() {
        while (true) {
            UI.cls();
            UI.header("Activity Log  [Page 4 of 4]", S);
            System.out.printf("  %d event(s) on record%n", UI.activityLog.size());
            UI.line();
            if (UI.activityLog.isEmpty()) {
                System.out.println("  No activity yet.");
            } else {
                int shown = 0;
                for (UI.LogEntry e : UI.activityLog) {
                    if (shown++ >= 40) {
                        System.out.printf("  %s... %d older event(s) not displayed ...%s%n",
                                UI.DIM, UI.activityLog.size() - 40, UI.RESET);
                        break;
                    }
                    String col =
                            e.message.contains("[EMERGENCY]") || e.message.contains("[REMOVED]") ? UI.RED   :
                            e.message.contains("[ADMIT]")    ||
                            e.message.contains("[TREATED]")  ||
                            e.message.contains("[COMPLETED]")                                    ? UI.GREEN :
                            e.message.contains("[SCHEDULED]")                                    ? UI.BLUE  :
                            e.message.contains("[ADMIN]")                                        ? UI.YELLOW
                                                                                                 : UI.RESET;
                    System.out.printf("  %s%s%s  %s%s%s%n",
                            UI.CYAN, e.time, UI.RESET, col, e.message, UI.RESET);
                }
            }
            UI.line();
            System.out.println("  " + UI.RED + "[1]" + UI.RESET + "  Clear Log");
            System.out.println("  " + UI.DIM + "[0]" + UI.RESET + "  Back");
            UI.line();
            try {
                switch (InputHelper.readMenu("  Choose: ", 0, 1)) {
                    case 1 -> {
                        if (InputHelper.readYesNo("  Clear all " + UI.activityLog.size() + " event(s)")) {
                            UI.activityLog.clear();
                            UI.msgPause(UI.YELLOW + "Activity log cleared." + UI.RESET);
                        } else {
                            UI.msgPause(UI.YELLOW + "Cancelled." + UI.RESET);
                        }
                    }
                    case 0 -> { UI.cls(); return; }
                }
            } catch (InputHelper.MainMenuException e) { UI.cls(); return; }
              catch (InputHelper.BackException  e) { UI.cls(); return; }
        }
    }

    // ===================================================================
    //  PAGE 5 - ADMIN PANEL
    // ===================================================================

    static void pageAdmin() {
        // -- Authentication - 3 attempts -------------------------------
        if (!S.adminUnlocked) {
            for (int attempt = 1; attempt <= 3; attempt++) {
                UI.cls();
                UI.header("Admin Panel - Authentication", S);
                System.out.println(UI.RED + UI.BOLD + "  [LOCK] Admin access required." + UI.RESET);
                System.out.printf("  Attempt %d of 3   %s(default PIN: 1234)%s%n%n",
                        attempt, UI.DIM, UI.RESET);
                UI.line();
                String pin = InputHelper.readPinOnce("  Enter 4-digit PIN: ");
                if (pin.equals(S.currentPin)) {
                    S.adminUnlocked = true;
                    UI.log("[ADMIN] Admin session started.");
                    break;
                }
                if (attempt < 3)
                    System.out.println(UI.RED + "  [X]  Incorrect PIN. "
                            + (3 - attempt) + " attempt(s) remaining." + UI.RESET);
            }
            if (!S.adminUnlocked) {
                UI.cls();
                UI.header("Admin Panel - Locked", S);
                UI.msgPause(UI.RED + "Too many failed attempts. Returning to main menu." + UI.RESET);
                return;
            }
        }

        // -- Admin menu ------------------------------------------------
        while (true) {
            UI.cls();
            UI.header("Administration Panel  [UNLOCK] Session Active", S);
            System.out.printf("  Active Doctors: %s%d%s%n", UI.BLUE, S.doctors.size(), UI.RESET);
            UI.line();
            System.out.println("  " + UI.GREEN  + "[1]" + UI.RESET + "  Add Doctor");
            System.out.println("  " + UI.RED    + "[2]" + UI.RESET + "  Remove Doctor");
            System.out.println("  " + UI.CYAN   + "[3]" + UI.RESET + "  List All Doctors");
            System.out.println("  " + UI.YELLOW + "[4]" + UI.RESET + "  Reset All Session Data");
            System.out.println("  " + UI.WHITE  + "[5]" + UI.RESET + "  Change Admin PIN");
            System.out.println("  " + UI.RED    + "[9]" + UI.RESET + "  Lock Admin Session");
            System.out.println("  " + UI.DIM    + "[0]" + UI.RESET + "  Back");
            UI.line();
            try {
                switch (InputHelper.readMenu("  Choose: ", 0, 9)) {
                    case 1 -> adminAddDoctor();
                    case 2 -> adminRemoveDoctor();
                    case 3 -> adminListDoctors(true);
                    case 4 -> adminResetData();
                    case 5 -> adminChangePin();
                    case 9 -> {
                        S.adminUnlocked = false;
                        UI.log("[ADMIN] Admin session ended.");
                        UI.msgPause(UI.RED + "[LOCK] Admin session locked." + UI.RESET);
                        UI.cls();
                        return;
                    }
                    case 0 -> { UI.cls(); return; }
                }
            } catch (InputHelper.MainMenuException e) { UI.cls(); return; }
              catch (InputHelper.BackException  e) { UI.cls(); return; }
        }
    }

    static void adminAddDoctor() {
        try {
            UI.cls();
            UI.header("Add New Doctor", S);
            System.out.println(UI.DIM + "  \"Dr.\" will be prepended automatically if omitted." + UI.RESET);
            UI.line();
            String raw  = InputHelper.readLine("  Doctor name: ", true);
            // Strip any existing "Dr." prefix then re-add normalised
            String name = "Dr. " + raw.replaceAll("(?i)^dr\\.\\s*", "").trim();
            if (S.doctors.contains(name)) {
                UI.msgPause(UI.YELLOW + "[X]  " + name + " is already registered." + UI.RESET); return;
            }
            S.doctors.add(name);
            UI.log("[ADMIN] Added doctor: " + name);
            UI.msgPause(UI.GREEN + "[OK] " + UI.BOLD + name + UI.RESET + UI.GREEN + " added to the system." + UI.RESET);
    
        } catch (InputHelper.BackException e) {
            UI.cls();
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }

    static void adminRemoveDoctor() {
        try {
            UI.cls();
            UI.header("Remove Doctor", S);
            if (S.doctors.size() <= 1) {
                UI.msgPause(UI.RED + "[X]  At least one doctor must remain." + UI.RESET); return;
            }
            adminListDoctors(false);
            int idx = InputHelper.readInt(
                    "  Select doctor number to remove [1-" + S.doctors.size() + "]: ", 1, S.doctors.size());
            String name = S.doctors.get(idx - 1);
            if (!InputHelper.readYesNo("  Remove " + UI.BOLD + name + UI.RESET + " from the system")) {
                UI.msgPause(UI.YELLOW + "Cancelled." + UI.RESET); return;
            }
            S.doctors.remove(idx - 1);
            UI.log("[ADMIN] Removed doctor: " + name);
            UI.msgPause(UI.RED + "[DEL]  " + name + " removed." + UI.RESET);
    
        } catch (InputHelper.BackException e) {
            UI.cls();
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }

    /**
     * Print the doctor list.
     * @param pause if true, waits for Enter after printing.
     */
    static void adminListDoctors(boolean pause) {
        UI.cls();
        UI.header("Registered Doctors  (" + S.doctors.size() + ")", S);
        for (int i = 0; i < S.doctors.size(); i++)
            System.out.printf("  %s[%d]%s  %s%n", UI.WHITE, i + 1, UI.RESET, S.doctors.get(i));
        System.out.println();
        if (pause) UI.pressEnter();
    }

    static void adminResetData() {
        try {
            UI.cls();
            UI.header("Reset All Session Data", S);
            System.out.println(UI.RED + UI.BOLD + "  [!]  ALL patients, appointments, records, and logs will be erased." + UI.RESET);
            System.out.println(UI.YELLOW + "     Doctors will be preserved." + UI.RESET);
            UI.line();
            if (!InputHelper.readYesNo("  Are you sure"))                    { UI.msgPause(UI.YELLOW + "Cancelled." + UI.RESET); return; }
            if (!InputHelper.readYesNo("  " + UI.RED + UI.BOLD + "Final confirmation - reset everything" + UI.RESET)) {
                UI.msgPause(UI.YELLOW + "Cancelled." + UI.RESET); return;
            }
            S.resetAll();
            UI.log("[ADMIN] All session data reset.");
            UI.msgPause(UI.YELLOW + "[DEL]  Session data reset. Doctors preserved." + UI.RESET);
    
        } catch (InputHelper.BackException e) {
            UI.cls();
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }

    static void adminChangePin() {
        try {
            // Step 1: verify current
            UI.cls();
            UI.header("Change Admin PIN  (Step 1 / 3)", S);
            UI.line();
            String current = InputHelper.readPinOnce("  Current PIN: ");
            if (!current.equals(S.currentPin)) {
                UI.msgPause(UI.RED + "[X]  Incorrect current PIN. No changes made." + UI.RESET); return;
            }

            // Step 2: new PIN
            UI.cls();
            UI.header("Change Admin PIN  (Step 2 / 3)", S);
            System.out.println(UI.DIM + "  Must be exactly 4 numeric digits." + UI.RESET);
            UI.line();
            String newPin = InputHelper.readPin("  New PIN: ");
            if (newPin.equals(S.currentPin)) {
                UI.msgPause(UI.YELLOW + "[X]  New PIN is the same as the current PIN. No change." + UI.RESET); return;
            }

            // Step 3: confirm
            UI.cls();
            UI.header("Change Admin PIN  (Step 3 / 3)", S);
            UI.line();
            String confirm = InputHelper.readPin("  Confirm new PIN: ");
            if (!confirm.equals(newPin)) {
                UI.msgPause(UI.RED + "[X]  PINs do not match. No change made." + UI.RESET); return;
            }

            S.currentPin = newPin;
            UI.log("[ADMIN] Admin PIN changed.");
            UI.msgPause(UI.GREEN + "[OK] PIN updated successfully." + UI.RESET);
    
        } catch (InputHelper.BackException e) {
            UI.cls();
        } catch (InputHelper.MainMenuException e) {
            UI.cls();
        }
    }
}
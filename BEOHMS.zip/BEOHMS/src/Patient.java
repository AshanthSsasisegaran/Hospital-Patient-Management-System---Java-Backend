import java.time.*;
import java.time.format.*;

// =======================================================================
//  Patient - core data record
//  status: "waiting" | "scheduled" | "treated" | "removed"
// =======================================================================

public class Patient {

    // -- Identity ---------------------------------------------------------
    public int     id;
    public String  name;
    public String  age;
    public String  gender;
    public String  phone;

    // -- Clinical ---------------------------------------------------------
    public int     severity;        // 1 (Critical) -> 5 (Routine)
    public String  condition;
    public String  notes;
    public boolean emergency;

    // -- Assignment -------------------------------------------------------
    public String  doctor;
    public String  apptTime;        // HH:MM  24-hour
    public String  apptDate;        // YYYY-MM-DD  (empty = not yet scheduled)

    // -- Metadata ---------------------------------------------------------
    public long    admitTime;       // System.currentTimeMillis() at admission
    public String  admitDate;       // human-readable admission timestamp
    public String  status;

    // ---------------------------------------------------------------------

    public Patient(int id, String name, String age, String gender, String phone,
                   int severity, String doctor, String apptTime,
                   String condition, String notes, boolean emergency) {

        this.id        = id;
        this.name      = name;
        this.age       = (age       == null || age.isBlank())       ? "-"                     : age.trim();
        this.gender    = (gender    == null)                         ? ""                      : gender.trim();
        this.phone     = (phone     == null)                         ? ""                      : phone.trim();
        this.severity  = severity;
        this.doctor    = doctor;
        this.apptTime  = (apptTime  == null || apptTime.isBlank())  ? "09:00"                 : apptTime.trim();
        this.condition = (condition == null || condition.isBlank())  ? "General consultation"  : condition.trim();
        this.notes     = (notes     == null)                         ? ""                      : notes.trim();
        this.emergency = emergency;
        this.apptDate  = "";        // set when an appointment is created
        this.admitTime = System.currentTimeMillis();
        this.admitDate = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        this.status    = "waiting";
    }

    /**
     * Shallow copy - used when placing a patient into the circular queue
     * so the queue holds its own reference without aliasing the heap entry.
     */
    public Patient copy() {
        Patient p      = new Patient(id, name, age, gender, phone,
                                     severity, doctor, apptTime,
                                     condition, notes, emergency);
        p.admitTime    = this.admitTime;
        p.admitDate    = this.admitDate;
        p.apptDate     = this.apptDate;
        p.status       = this.status;
        return p;
    }

    @Override
    public String toString() {
        return String.format("ID:%-4d  Sev:%d %-8s  %-22s  Dr:%-14s  %s",
                id, severity, UI.SEV_LABELS[severity], name, doctor, apptTime);
    }
}
import java.util.*;

//  MinHeap - binary min-heap ordered by (severity ASC, admitTime ASC)
//
//  insert(p)        O(log n)
//  extractMin()     O(log n)
//  remove(id)       O(n) find + O(log n) repair
//  peek()           O(1)


public class MinHeap {

    // Package-visible so AppState.resetAll() can clear it directly
    final List<Patient> h = new ArrayList<>();

    // -- Index helpers -----------------------------------------------------
    private int par(int i)   { return (i - 1) / 2; }
    private int left(int i)  { return 2 * i + 1;   }
    private int right(int i) { return 2 * i + 2;   }

    /** Compare two patients: lower severity value = higher priority. */
    private int cmp(Patient a, Patient b) {
        if (a.severity != b.severity) return a.severity - b.severity;
        return Long.compare(a.admitTime, b.admitTime);
    }

    private void swap(int a, int b) {
        Patient t = h.get(a);
        h.set(a, h.get(b));
        h.set(b, t);
    }

    // -- Core operations ---------------------------------------------------

    public void insert(Patient p) {
        h.add(p);
        bubbleUp(h.size() - 1);
    }

    private void bubbleUp(int i) {
        while (i > 0) {
            int p = par(i);
            if (cmp(h.get(i), h.get(p)) < 0) { swap(i, p); i = p; }
            else break;
        }
    }

    public Patient extractMin() {
        if (h.isEmpty()) return null;
        Patient min  = h.get(0);
        Patient last = h.remove(h.size() - 1);
        if (!h.isEmpty()) { h.set(0, last); heapifyDown(0); }
        return min;
    }

    private void heapifyDown(int i) {
        int n = h.size(), s = i;
        int l = left(i), r = right(i);
        if (l < n && cmp(h.get(l), h.get(s)) < 0) s = l;
        if (r < n && cmp(h.get(r), h.get(s)) < 0) s = r;
        if (s != i) { swap(i, s); heapifyDown(s); }
    }

    /**
     * Remove the patient with the given id.
     * Returns true if found and removed, false if not present.
     */
    public boolean remove(int id) {
        int idx = indexOf(id);
        if (idx == -1) return false;
        Patient last = h.remove(h.size() - 1);
        if (idx < h.size()) {
            h.set(idx, last);
            bubbleUp(idx);
            heapifyDown(idx);
        }
        return true;
    }

    // -- Query helpers ------------------------------------------------------

    public Patient peek()    { return h.isEmpty() ? null : h.get(0); }
    public int     size()    { return h.size(); }
    public boolean isEmpty() { return h.isEmpty(); }

    public Patient findById(int id) {
        for (Patient p : h) if (p.id == id) return p;
        return null;
    }

    private int indexOf(int id) {
        for (int i = 0; i < h.size(); i++) if (h.get(i).id == id) return i;
        return -1;
    }

    /**
     * Returns a fully sorted copy of the heap contents.
     * The backing array is NOT mutated.
     */
    public List<Patient> sorted() {
        List<Patient> copy = new ArrayList<>(h);
        copy.sort(this::cmp);
        return copy;
    }

    /**
     * Returns an unmodifiable view of the raw backing array
     * (heap order, not sorted order).
     */
    public List<Patient> rawArray() {
        return Collections.unmodifiableList(h);
    }
}
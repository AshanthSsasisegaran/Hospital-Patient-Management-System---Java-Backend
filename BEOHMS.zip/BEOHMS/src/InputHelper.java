import java.time.*;
import java.time.format.*;
import java.util.*;

// =======================================================================
//  InputHelper -- validated, looping input primitives
//
//  NAVIGATION
//  ----------
//  At ANY prompt the user can type:
//    "z"        -> BackException      go back one step
//    "q"        -> MainMenuException  jump straight to the main menu
//
//  On the MAIN MENU itself, [0] is the normal "Exit program" choice handled
//  by the menu switch. "z" still fires BackException from readMenu() though
//  (readMenu only suppresses the "0"-as-back behaviour, not "z").
//
//  Every Scanner read is wrapped in try/catch(Exception).
//  Every method loops until valid input OR a navigation signal.
// =======================================================================

public class InputHelper {

    // -- Navigation exceptions --------------------------------------------

    /** "z" at any non-menu prompt -- go back one step. */
    public static class BackException extends RuntimeException {
        public BackException() { super("back"); }
    }

    /** "q" at any prompt -- jump straight back to the main menu. */
    public static class MainMenuException extends RuntimeException {
        public MainMenuException() { super("main-menu"); }
    }

    private static final Scanner IN = new Scanner(System.in);

    // -- Raw line read (never throws, never null) --------------------------
    public static String rawLine() {
        try {
            String s = IN.nextLine();
            return (s == null) ? "" : s.trim();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Check for navigation signals and throw the appropriate exception.
     * Called inside every looping read method.
     */
    private static void checkNav(String val) {
        String v = val.toLowerCase();
        if (v.equals("z") || v.equals("back"))          throw new BackException();
        if (v.equals("q") || v.equals("menu")
                          || v.equals("quit"))          throw new MainMenuException();
    }

    /** Navigation hint shown once above every interactive prompt. */
    private static void navHint() {
        System.out.println(UI.DIM
                + "  (z = back  |  q = main menu)"
                + UI.RESET);
    }

    // =====================================================================
    //  PUBLIC PRIMITIVES
    // =====================================================================

    /**
     * Read a trimmed string.
     * required=true  -> loops until non-empty value given.
     * Throws BackException / MainMenuException on navigation input.
     */
    public static String readLine(String prompt, boolean required) {
        navHint();
        while (true) {
            try {
                System.out.print(prompt);
                String val = rawLine();
                checkNav(val);
                if (required && val.isEmpty()) {
                    System.out.println(UI.RED
                            + "  [X]  This field is required -- please enter a value."
                            + UI.RESET);
                    continue;
                }
                return val;
            } catch (BackException | MainMenuException e) {
                throw e;
            } catch (Exception e) {
                System.out.println(UI.RED + "  [X]  Input error: "
                        + e.getMessage() + ". Try again." + UI.RESET);
            }
        }
    }

    /**
     * Read an integer in [lo, hi] at a form prompt (not a menu).
     * "z" throws BackException regardless of what numbers are valid.
     * Use readMenu() for menus where 0 is a valid "Back" choice.
     */
    public static int readInt(String prompt, int lo, int hi) {
        navHint();
        while (true) {
            try {
                System.out.print(prompt);
                String raw = rawLine();
                checkNav(raw);          // "z" -> BackException
                if (raw.isEmpty()) {
                    System.out.println(UI.RED + "  [X]  Enter a number between "
                            + lo + " and " + hi + "." + UI.RESET);
                    continue;
                }
                int val = Integer.parseInt(raw);
                if (val < lo || val > hi) {
                    System.out.println(UI.RED + "  [X]  Out of range -- choose between "
                            + lo + " and " + hi + "." + UI.RESET);
                    continue;
                }
                return val;
            } catch (BackException | MainMenuException e) {
                throw e;
            } catch (NumberFormatException e) {
                System.out.println(UI.RED + "  [X]  Not a number -- enter a whole number between "
                        + lo + " and " + hi + "." + UI.RESET);
            } catch (Exception e) {
                System.out.println(UI.RED + "  [X]  Input error: "
                        + e.getMessage() + ". Try again." + UI.RESET);
            }
        }
    }

    /**
     * Read a menu integer where 0 is a valid built-in "Back" option shown
     * in the menu itself.  "0" is treated as a normal integer choice here
     * (the menu's case 0 handles navigation).  Only "q" triggers navigation.
     * Does NOT print a nav hint -- the menu already lists [0] Back.
     */
    public static int readMenu(String prompt, int lo, int hi) {
        while (true) {
            try {
                System.out.print(prompt);
                String raw = rawLine();
                // Only "q" and "z" navigate -- "0" is a valid menu item
                String v = raw.toLowerCase();
                if (v.equals("z") || v.equals("back"))  throw new BackException();
                if (v.equals("q") || v.equals("menu") || v.equals("quit"))
                    throw new MainMenuException();
                if (raw.isEmpty()) {
                    System.out.println(UI.RED + "  [X]  Enter a number between "
                            + lo + " and " + hi + "." + UI.RESET);
                    continue;
                }
                int val = Integer.parseInt(raw);
                if (val < lo || val > hi) {
                    System.out.println(UI.RED + "  [X]  Out of range -- choose between "
                            + lo + " and " + hi + "." + UI.RESET);
                    continue;
                }
                return val;
            } catch (BackException | MainMenuException e) {
                throw e;
            } catch (NumberFormatException e) {
                System.out.println(UI.RED + "  [X]  Not a number -- enter a whole number between "
                        + lo + " and " + hi + "." + UI.RESET);
            } catch (Exception e) {
                System.out.println(UI.RED + "  [X]  Input error: "
                        + e.getMessage() + ". Try again." + UI.RESET);
            }
        }
    }

    /**
     * Read a patient age.
     * Blank -> returns ""; integer 0-130 -> returns string value.
     */
    public static String readAge(String prompt) {
        navHint();
        while (true) {
            try {
                System.out.print(prompt);
                String val = rawLine();
                checkNav(val);
                if (val.isEmpty()) return "";
                int age = Integer.parseInt(val);
                if (age < 0 || age > 130) {
                    System.out.println(UI.RED
                            + "  [X]  Age must be 0-130 (or press Enter to skip)."
                            + UI.RESET);
                    continue;
                }
                return val;
            } catch (BackException | MainMenuException e) {
                throw e;
            } catch (NumberFormatException e) {
                System.out.println(UI.RED
                        + "  [X]  Age must be a whole number 0-130 (or press Enter to skip)."
                        + UI.RESET);
            } catch (Exception e) {
                System.out.println(UI.RED + "  [X]  Input error: "
                        + e.getMessage() + ". Try again." + UI.RESET);
            }
        }
    }

    /**
     * Read a 24-hour clock time (HH:MM).
     * Blank -> returns defaultVal (if not required).
     * Strict two-digit hour: "9:00" rejected, must be "09:00".
     */
    public static String readTime(String prompt, String defaultVal, boolean required) {
        navHint();
        while (true) {
            try {
                System.out.print(prompt);
                String val = rawLine();
                checkNav(val);
                if (val.isEmpty()) {
                    if (!required) return defaultVal;
                    System.out.println(UI.RED
                            + "  [X]  Time is required. Format: HH:MM (e.g. 09:00 or 14:30)."
                            + UI.RESET);
                    continue;
                }
                if (!val.matches("^([01]\\d|2[0-3]):[0-5]\\d$")) {
                    System.out.println(UI.RED
                            + "  [X]  \"" + val + "\" is not a valid 24-hour time." + UI.RESET);
                    System.out.println(UI.RED
                            + "       Format: HH:MM (hour must be 2 digits -- 09:00 not 9:00)."
                            + UI.RESET);
                    continue;
                }
                try {
                    LocalTime.parse(val, DateTimeFormatter.ofPattern("HH:mm"));
                } catch (DateTimeParseException dtpe) {
                    System.out.println(UI.RED
                            + "  [X]  \"" + val + "\" failed clock parsing. Use HH:MM (24-hour)."
                            + UI.RESET);
                    continue;
                }
                return val;
            } catch (BackException | MainMenuException e) {
                throw e;
            } catch (Exception e) {
                System.out.println(UI.RED + "  [X]  Input error: "
                        + e.getMessage() + ". Try again." + UI.RESET);
            }
        }
    }

    /**
     * Read a calendar date (YYYY-MM-DD). Must be today or a future date.
     */
    public static String readDate(String prompt, String defaultVal, boolean required) {
        LocalDate today   = LocalDate.now();
        LocalDate maxDate = today.plusYears(1);
        navHint();
        System.out.println(UI.DIM
                + "  Valid range: " + today + " to " + maxDate + " (max 1 year ahead)."
                + UI.RESET);
        while (true) {
            try {
                System.out.print(prompt);
                String val = rawLine();
                checkNav(val);
                if (val.isEmpty()) {
                    if (!required) return defaultVal;
                    System.out.println(UI.RED
                            + "  [X]  Date is required. Format: YYYY-MM-DD (e.g. " + today + ")."
                            + UI.RESET);
                    continue;
                }
                LocalDate parsed;
                try {
                    parsed = LocalDate.parse(val, DateTimeFormatter.ISO_LOCAL_DATE);
                } catch (DateTimeParseException dtpe) {
                    System.out.println(UI.RED
                            + "  [X]  \"" + val + "\" is not a valid date." + UI.RESET);
                    System.out.println(UI.RED
                            + "       Format: YYYY-MM-DD (e.g. " + today + ")." + UI.RESET);
                    continue;
                }
                if (parsed.isBefore(today)) {
                    System.out.println(UI.RED
                            + "  [X]  Date cannot be in the past. Today is " + today + "."
                            + UI.RESET);
                    continue;
                }
                if (parsed.isAfter(maxDate)) {
                    System.out.println(UI.RED
                            + "  [X]  Date cannot be more than 1 year ahead."
                            + " Latest allowed: " + maxDate + "."
                            + UI.RESET);
                    continue;
                }
                return val;
            } catch (BackException | MainMenuException e) {
                throw e;
            } catch (Exception e) {
                System.out.println(UI.RED + "  [X]  Input error: "
                        + e.getMessage() + ". Try again." + UI.RESET);
            }
        }
    }

    /**
     * Read a phone number.
     * Blank -> returns "".
     * Non-blank -> digits/spaces/hyphens/parens/plus only, min 7 digits.
     */
    public static String readPhone(String prompt) {
        navHint();
        while (true) {
            try {
                System.out.print(prompt);
                String val = rawLine();
                checkNav(val);
                if (val.isEmpty()) return "";
                if (!val.matches("[0-9 ()\\-+]+")) {
                    System.out.println(UI.RED
                            + "  [X]  Phone may only contain digits, spaces, hyphens, "
                            + "parentheses, and '+'." + UI.RESET);
                    System.out.println(UI.RED + "       Press Enter to skip." + UI.RESET);
                    continue;
                }
                long digits = val.chars().filter(Character::isDigit).count();
                if (digits < 7) {
                    System.out.println(UI.RED
                            + "  [X]  Phone must contain at least 7 digits "
                            + "(or press Enter to skip)." + UI.RESET);
                    continue;
                }
                return val;
            } catch (BackException | MainMenuException e) {
                throw e;
            } catch (Exception e) {
                System.out.println(UI.RED + "  [X]  Input error: "
                        + e.getMessage() + ". Try again." + UI.RESET);
            }
        }
    }

    /**
     * Read a yes/no answer. Accepts y/yes/n/no (case-insensitive).
     * Also supports navigation: "z" = back, "q" = main menu.
     */
    public static boolean readYesNo(String prompt) {
        navHint();
        while (true) {
            try {
                System.out.print(prompt + " (y/n) ");
                String val = rawLine().toLowerCase();
                checkNav(val);
                if (val.equals("y") || val.equals("yes")) return true;
                if (val.equals("n") || val.equals("no"))  return false;
                System.out.println(UI.RED + "  [X]  Please type 'y' or 'n'." + UI.RESET);
            } catch (BackException | MainMenuException e) {
                throw e;
            } catch (Exception e) {
                System.out.println(UI.RED + "  [X]  Input error: "
                        + e.getMessage() + ". Try again." + UI.RESET);
            }
        }
    }

    /**
     * Read a 4-digit numeric PIN (loops until valid format).
     * Navigation still works: "z" = back, "q" = main menu.
     */
    public static String readPin(String prompt) {
        navHint();
        while (true) {
            try {
                System.out.print(prompt);
                String val = rawLine();
                checkNav(val);
                if (val.matches("\\d{4}")) return val;
                System.out.println(UI.RED
                        + "  [X]  PIN must be exactly 4 digits (e.g. 1234)." + UI.RESET);
            } catch (BackException | MainMenuException e) {
                throw e;
            } catch (Exception e) {
                System.out.println(UI.RED + "  [X]  Input error: "
                        + e.getMessage() + ". Try again." + UI.RESET);
            }
        }
    }

    /**
     * Single-attempt PIN read with no looping and no navigation checking.
     * Used in the admin auth loop where attempts are counted externally.
     */
    public static String readPinOnce(String prompt) {
        System.out.print(prompt);
        return rawLine();
    }
}
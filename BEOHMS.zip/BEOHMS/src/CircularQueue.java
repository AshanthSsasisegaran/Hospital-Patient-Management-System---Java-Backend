// =======================================================================
//  CircularQueue - fixed-capacity 8-slot circular buffer
//
//  Each slot holds an Appointment (patient snapshot + chosen date/time).
//
//  enqueue(a)   O(1)
//  dequeue()    O(1)
//  peek()       O(1)
// =======================================================================

public class CircularQueue {

    // -- Appointment record stored per slot --------------------------------
    public static class Appointment {
        public final Patient patient;
        public final String  date;       // YYYY-MM-DD
        public final String  time;       // HH:MM  24-hour
        public final String  doctor;
        public final String  bookedAt;   // timestamp when booked

        public Appointment(Patient patient, String date, String time, String doctor) {
            this.patient  = patient;
            this.date     = date;
            this.time     = time;
            this.doctor   = doctor;
            this.bookedAt = java.time.LocalDateTime.now()
                    .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        }

        @Override
        public String toString() {
            return String.format("%-22s  %s  %s  Dr.%s", patient.name, date, time, doctor);
        }
    }

    // -- Buffer ------------------------------------------------------------
    public static final int    CAP  = 8;
    final               Appointment[] data = new Appointment[CAP];
    public int head  = 0;
    public int tail  = 0;
    public int count = 0;

    // -- State checks ------------------------------------------------------
    public boolean isFull()  { return count == CAP; }
    public boolean isEmpty() { return count == 0;   }

    // -- Core operations ---------------------------------------------------

    public boolean enqueue(Appointment a) {
        if (isFull()) return false;
        data[tail] = a;
        tail = (tail + 1) % CAP;
        count++;
        return true;
    }

    public Appointment dequeue() {
        if (isEmpty()) return null;
        Appointment item = data[head];
        data[head] = null;
        head = (head + 1) % CAP;
        count--;
        return item;
    }

    public Appointment peek() { return isEmpty() ? null : data[head]; }

    /**
     * Remove all appointments whose patient id matches.
     * Called when a patient is deleted from the system.
     */
    public void removeByPatientId(int patientId) {
        for (int i = 0; i < CAP; i++) {
            if (data[i] != null && data[i].patient.id == patientId) {
                data[i] = null;
                count   = Math.max(0, count - 1);
            }
        }
    }

    /**
     * Find all appointments for a given date (YYYY-MM-DD).
     * Returns an array of (slot-index, Appointment) pairs as Object[2][].
     */
    public java.util.List<int[]> slotsForDate(String date) {
        java.util.List<int[]> result = new java.util.ArrayList<>();
        for (int i = 0; i < CAP; i++) {
            if (data[i] != null && date.equals(data[i].date)) {
                result.add(new int[]{ i });
            }
        }
        return result;
    }
}
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.Deque;

// =======================================================================
//  UI - display constants and shared rendering helpers
//
//  All screen-output formatting lives here so other classes stay clean.
// =======================================================================

public class UI {

    // -- ANSI codes --------------------------------------------------------
    public static final String RESET   = "\u001B[0m";
    public static final String BOLD    = "\u001B[1m";
    public static final String DIM     = "\u001B[2m";
    public static final String RED     = "\u001B[31m";
    public static final String GREEN   = "\u001B[32m";
    public static final String YELLOW  = "\u001B[33m";
    public static final String BLUE    = "\u001B[34m";
    public static final String MAGENTA = "\u001B[35m";
    public static final String CYAN    = "\u001B[36m";
    public static final String WHITE   = "\u001B[37m";
    public static final String BG_RED  = "\u001B[41m";
    public static final String ORANGE  = "\u001B[38;5;208m";

    // -- Severity metadata -------------------------------------------------
    public static final String[] SEV_LABELS  = { "", "Critical", "Urgent", "Moderate", "Minor", "Routine" };
    public static final String[] SEV_ICONS   = { "", "[!!!]", "[!! ]", "[ ~ ]", "[ + ]", "[   ]" };
    public static final String[] SEV_COLOURS = { "", RED, ORANGE, YELLOW, GREEN, BLUE };

    // -- Activity log (lives here so all pages share it) -------------------
    public static final Deque<LogEntry> activityLog = new ArrayDeque<>();

    public static class LogEntry {
        public final String time, message;
        public LogEntry(String message) {
            this.time    = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
            this.message = message;
        }
    }

    public static void log(String msg) {
        activityLog.addFirst(new LogEntry(msg));
        if (activityLog.size() > 200) activityLog.removeLast();
    }

    // -- Terminal control --------------------------------------------------

    /** Hard-clear the terminal (ANSI ESC codes - works on macOS / Linux / Windows Terminal). */
    public static void cls() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static void line()  { System.out.println(CYAN + "-".repeat(72) + RESET); }
    public static void dline() { System.out.println(CYAN + "=".repeat(72) + RESET); }

    // -- Page header with live stats ---------------------------------------

    public static void header(String title, AppState st) {
        dline();
        System.out.println(BOLD + CYAN + "  MedQueue  " + RESET + BOLD + "|  " + title + RESET);
        dline();
        System.out.printf(
            "  %sQueue:%s %-4d  %sAppts:%s %-4d  %sTreated:%s %-4d  "
            + "%sEmergencies:%s %-4d  %sRecords:%s %d%n",
            YELLOW, RESET, st.heap.size(),
            BLUE,   RESET, st.cq.count,
            GREEN,  RESET, st.treatedCount,
            RED,    RESET, st.emergencyCount,
            MAGENTA,RESET, st.patientRecords.size());
        line();
    }

    // -- Inline messages ---------------------------------------------------

    public static void msg(String m)      { System.out.println("\n  " + BOLD + m + RESET); }
    public static void msgPause(String m) { msg(m); pressEnter(); }

    public static void pressEnter() {
        System.out.print(CYAN + "  [Press Enter to continue]" + RESET);
        InputHelper.rawLine();
    }

    // -- Status helpers ----------------------------------------------------

    public static String statusLabel(String s) {
        return switch (s) {
            case "waiting"   -> YELLOW + "Waiting"   + RESET;
            case "scheduled" -> BLUE   + "Scheduled" + RESET;
            case "treated"   -> GREEN  + "Treated"   + RESET;
            case "removed"   -> RED    + "Removed"   + RESET;
            default          -> s;
        };
    }

    // -- Shared table helpers ----------------------------------------------

    /**
     * Prints a compact sortedpatient table (ID | Severity | Name | Doctor | Time).
     * Used by treat/remove actions to give the user a reference.
     */
    public static void printQueueTable(AppState st) {
        System.out.printf("  %-6s  %-14s  %-22s  %-14s  %s%n",
                "ID", "Severity", "Name", "Doctor", "Time");
        line();
        for (Patient p : st.heap.sorted()) {
            System.out.printf("  %-6d  %s%-14s%s  %-22s  %-14s  %s%n",
                    p.id,
                    SEV_COLOURS[p.severity], p.severity + " " + SEV_LABELS[p.severity], RESET,
                    p.name + (p.emergency ? " (!)" : ""),
                    p.doctor, p.apptTime);
        }
    }

    /**
     * Prints a doctor selection list.
     */
    public static void printDoctorList(AppState st) {
        System.out.println(BOLD + "  Available Doctors:" + RESET);
        for (int i = 0; i < st.doctors.size(); i++)
            System.out.printf("    %s[%d]%s  %s%n", WHITE, i + 1, RESET, st.doctors.get(i));
    }
}
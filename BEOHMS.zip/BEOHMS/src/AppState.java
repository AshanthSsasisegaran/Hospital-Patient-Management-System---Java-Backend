import java.util.*;

// =======================================================================
//  AppState - single container for all mutable session data
//
//  Passed by reference to every page handler so there is exactly one
//  source of truth and no global statics scattered across files.
// =======================================================================

public class AppState {

    // -- Data structures ---------------------------------------------------
    public final MinHeap       heap           = new MinHeap();
    public final CircularQueue cq             = new CircularQueue();
    public final List<Patient> patientRecords = new ArrayList<>();
    public final List<String>  doctors        = new ArrayList<>(Arrays.asList(
            "Dr. Patel", "Dr. Chen", "Dr. Okafor", "Dr. Rivera", "Dr. Singh"));

    // -- Counters ----------------------------------------------------------
    public int     patientCount   = 0;
    public int     treatedCount   = 0;
    public int     emergencyCount = 0;

    // -- Admin session -----------------------------------------------------
    public boolean adminUnlocked  = false;
    public String  currentPin     = "1234";

    // ---------------------------------------------------------------------
    //  Helpers used by multiple pages
    // ---------------------------------------------------------------------

    /** Update a patient record's status by id. No-op if not found. */
    public void setStatus(int id, String status) {
        for (Patient r : patientRecords)
            if (r.id == id) { r.status = status; return; }
    }

    /** Find a patient record by id (from full record list, not just heap). */
    public Patient findRecord(int id) {
        for (Patient r : patientRecords) if (r.id == id) return r;
        return null;
    }

    /**
     * Reset all session data except the doctor list.
     * Called from the Admin panel's "Reset" option.
     */
    public void resetAll() {
        heap.h.clear();
        for (int i = 0; i < CircularQueue.CAP; i++) cq.data[i] = null;
        cq.head = 0; cq.tail = 0; cq.count = 0;
        UI.activityLog.clear();
        patientRecords.clear();
        patientCount   = 0;
        treatedCount   = 0;
        emergencyCount = 0;
    }

    // ---------------------------------------------------------------------
    //  Demo seed (called once at startup)
    // ---------------------------------------------------------------------

    public void seedDemo() {
        // { name, age, gender, phone, severity, doctor, apptTime, condition, notes }
        Object[][] demo = {
            { "Alice King", "45", "Female", "416-555-0101", 3, "Dr. Chen",   "10:30",
              "Moderate chest pain",  ""                       },
            { "Bob Marley",     "72", "Male",   "416-555-0102", 2, "Dr. Patel",  "09:15",
              "Difficulty breathing", "History of COPD"        },
            { "Kim Wood",      "28", "Female", "416-555-0103", 5, "Dr. Rivera", "11:00",
              "Routine check-up",     ""                       },
            { "David Mann",     "60", "Male",   "416-555-0104", 1, "Dr. Okafor", "08:00",
              "Severe head trauma",   "Unconscious on arrival" },
            { "Elena Johnson",   "35", "Female", "416-555-0105", 4, "Dr. Singh",  "12:00",
              "Minor laceration",     ""                       },
        };

        for (Object[] d : demo) {
            patientCount++;
            boolean em = (int) d[4] == 1;
            Patient p  = new Patient(patientCount,
                    (String) d[0], (String) d[1], (String) d[2], (String) d[3],
                    (int)    d[4], (String) d[5], (String) d[6],
                    (String) d[7], (String) d[8], em);
            p.admitTime = System.currentTimeMillis() + patientCount;
            if (em) emergencyCount++;
            heap.insert(p);
            patientRecords.add(p);
        }

        // Schedule top-3 into the circular queue with today's date as placeholder
        String today = java.time.LocalDate.now().toString();
        java.util.List<Patient> top = heap.sorted();
        for (int i = 0; i < Math.min(3, top.size()); i++) {
            Patient p = top.get(i);
            CircularQueue.Appointment appt = new CircularQueue.Appointment(
                    p.copy(), today, p.apptTime, p.doctor);
            p.apptDate = today;
            cq.enqueue(appt);
            setStatus(p.id, "scheduled");
        }

        UI.log("[SYSTEM] Demo data loaded - 5 patients admitted, 3 appointments scheduled.");
    }
}